#!/usr/bin/php -q
<?php

#
# cacti script to read lm_sensors stats with ucd/net-snmp
#
# sensors are grouped into type-specific hierarchies
# index values are provided but are ($oid -1) so they are ignored
# sensor name OID values used for index values
# index values are defined for each type-specific hierarchy but ignored
#
# additional data is fetched as needed
#

#
# default includes
#
include(dirname(__FILE__) . "/../include/config.php");
include(dirname(__FILE__) . "/../lib/snmp.php");

#
# global declarations
#
global $sensor_type;
global $snmp_hostname;
global $snmp_community;
global $snmp_version;
global $snmp_username;
global $snmp_password;
global $snmp_port;
global $snmp_timeout;
global $snmp_array;
global $cacti_request;
global $cacti_request_type;
global $cacti_request_index;
global $oid;
global $cmdoutput;
global $cmdoutputcount;
global $outputcount;

#
# make sure enough parameters were provided
#
if (count($_SERVER['argv']) < 5) {

	echo ("FAILED -- insufficient parameters provided\n");

	displaySyntax();

	exit(1);
}

#
# 1st parameter is always $sensor_type
#
$sensor_type = strtolower($_SERVER['argv'][1]);

if (($sensor_type != "fan") &&
	($sensor_type != "temperature") &&
	($sensor_type != "voltage")) {

	echo ("FAILED -- invalid sensor type\n");

	displaySyntax();

	exit(1);
}

#
# 2nd parameter is always $snmp_hostname
#
$snmp_hostname = substr($_SERVER['argv'][2],0,(strlen($_SERVER['argv'][2]) - 1));

#
# 3rd parameter is always $snmp_community; testing is done after we have the version
#
$snmp_community = substr($_SERVER['argv'][3],0,(strlen($_SERVER['argv'][3]) - 1));

#
# 4th parameter is always $snmp_version
#
$snmp_version = substr($_SERVER['argv'][4],0,(strlen($_SERVER['argv'][4]) - 1));

if (($snmp_version != 1) and ($snmp_version != 2) and ($snmp_version != 3)) {

	echo ("FAILED -- \"$snmp_version\" is not a valid SNMP version\n");

	displaySyntax();

	exit(1);
}

if (($snmp_version != 3) and ($snmp_community == "")) {

	echo ("FAILED -- invalid SNMP community string\n");

	displaySyntax();

	exit(1);
}

#
# 5th parameter is always $snmp_username
#
$snmp_username = substr($_SERVER['argv'][5],0,(strlen($_SERVER['argv'][5]) - 1));

#
# 6th parameter is always $snmp_password
#
$snmp_password = substr($_SERVER['argv'][6],0,(strlen($_SERVER['argv'][6]) - 1));

#
# 7th parameter is always $snmp_port
#
$snmp_port = substr($_SERVER['argv'][7],0,(strlen($_SERVER['argv'][7]) - 1));

if (is_numeric($snmp_port) == FALSE) {

	echo ("FAILED -- \"$snmp_port\" is not a numeric port number \n");

	displaySyntax();

	exit(1);
}

#
# 8th parameter is always $snmp_timeout
#
$snmp_timeout = substr($_SERVER['argv'][8],0,(strlen($_SERVER['argv'][8]) - 1));

if (is_numeric($snmp_timeout) == FALSE) {

	echo ("FAILED -- \"$snmp_timeout\" is not a numeric timeout value \n");

	displaySyntax();

	exit(1);
}

#
# Cacti's SNMP timeout uses milliseconds, while PHP uses the value
# from Net-SNMP's header files, which is typically microseconds.
# Normalize by multiplying the timeout parameter value by 1000.
#
$snmp_timeout = ($snmp_timeout * 1000);

#
# 9th parameter is always $cacti_request
#
# "query" and "get" have additional parameters
#
$cacti_request = strtolower($_SERVER['argv'][9]);

if (($cacti_request == "query") ||
	($cacti_request == "get")) {

	if (isset($_SERVER['argv'][10]) === FALSE) {

		echo ("FAILED -- incomplete cacti request\n");

		displaySyntax();

		exit(1);
	}

	else {
		$cacti_request_type = strtolower($_SERVER['argv'][10]);

		if (($cacti_request_type != "sensordevice") &&
			($cacti_request_type != "sensorname") &&
			($cacti_request_type != "sensorreading")) {

			echo ("FAILED -- unknown cacti request type\n");

			displaySyntax();

			exit(1);
		}
	}

	if ($cacti_request == "get") {

		if (isset($_SERVER['argv'][11]) === FALSE) {

			echo ("FAILED -- incomplete cacti request\n");

			displaySyntax();

			exit(1);
		}

		else {
			$cacti_request_index = $_SERVER['argv'][11];

			if (($cacti_request_index == "") ||
				($cacti_request_index < 0)) {

				echo ("FAILED -- unknown cacti index value\n");

				displaySyntax();

				exit(1);
			}
		}
	}
}

elseif ($cacti_request !== "index") {

	echo ("FAILED -- unknown cacti request\n");

	displaySyntax();

	exit(1);
}

#
# define a nested array of the OIDs and their labels
#
switch ($sensor_type) {

case "temperature":
	$oid = array (
		array ("sensorIndex", ".1.3.6.1.4.1.2021.13.16.2.1.1"),
		array ("sensorName", ".1.3.6.1.4.1.2021.13.16.2.1.2"),
		array ("sensorReading", ".1.3.6.1.4.1.2021.13.16.2.1.3"));
	break;

case "fan":
	$oid = array (
		array ("sensorIndex", ".1.3.6.1.4.1.2021.13.16.3.1.1"),
		array ("sensorName", ".1.3.6.1.4.1.2021.13.16.3.1.2"),
		array ("sensorReading", ".1.3.6.1.4.1.2021.13.16.3.1.3"));
	break;

case "voltage":
	$oid = array (
		array ("sensorIndex", ".1.3.6.1.4.1.2021.13.16.4.1.1"),
		array ("sensorName", ".1.3.6.1.4.1.2021.13.16.4.1.2"),
		array ("sensorReading", ".1.3.6.1.4.1.2021.13.16.4.1.3"));
	break;
}

#
# if they want all the sensors, get them all
#
if (($cacti_request == "index") || ($cacti_request == "query")) {

	#
	# get a list of all sensors by name
	#
	$snmp_array = cacti_snmp_walk($snmp_hostname,
		$snmp_community,
		$oid[0][1],
		$snmp_version,
		$snmp_username,
		$snmp_password,
		$snmp_port,
		$snmp_timeout);

	#
	# create a local array
	#
	$cmdoutputcount = 0;

	while ($cmdoutputcount < count($snmp_array)) {

		#
		# grab the index OID, which will be used to close all other requests
		#
		if (preg_match('/(\d+)$/', $snmp_array[$cmdoutputcount]['oid'], $scratch) == 1) {

			$cmdoutput[$cmdoutputcount][0] = $scratch[1];
		}

		$cmdoutputcount++;
	}

	#
	# see if any sensors were returned
	#
	if ($cmdoutputcount == 0) {

		echo ("FAILED -- no matching sensors were found\n");

		exit(1);
	}
}

#
# they just want one sensor ("get")
#
else {
	#
	# see if a sensor index exists for the requested index value
	#
	$scratch = cacti_snmp_get($snmp_hostname,
		$snmp_community,
		($oid[0][1] . "." . $cacti_request_index),
		$snmp_version,
		$snmp_username,
		$snmp_password,
		$snmp_port,
		$snmp_timeout);

	if ($scratch == ($cacti_request_index - 1)) {

		$cmdoutput[0][0] = $cacti_request_index;
	}

	else {
		echo ("FAILED -- no matching sensors were found\n");

		exit(1);
	}
}

#
# queries and lookups require additional processing
#
if (($cacti_request == "query") || ($cacti_request == "get")) {

	#
	# they want the sensor name(s)
	#
	if ($cacti_request_type == "sensorname") {

		$cmdoutputcount = 0;

		while ($cmdoutputcount < count($cmdoutput)) {

			#
			# get the sensor name for each entry
			#
			$scratch = cacti_snmp_get($snmp_hostname,
				$snmp_community,
				($oid[1][1] . "." . $cmdoutput[$cmdoutputcount][0]),
				$snmp_version,
				$snmp_username,
				$snmp_password,
				$snmp_port,
				$snmp_timeout);

			#
			# if the name is long and has spaces, trim it down
			#
			while ((strlen($scratch) > 9) && (strpos($scratch, " ") !== FALSE)) {

				$scratch = (substr($scratch,0, (strrpos($scratch, " "))));
			}

			#
			# if the name is still long, chop it manually
			#
			if (strlen($scratch) > 12) {

				$scratch = (substr($scratch,0,12));
			}

			$cmdoutput[$cmdoutputcount][1] = $scratch;

			$cmdoutputcount++;
		}
	}

	#
	# they want the sensor reading(s)
	#
	if ($cacti_request_type == "sensorreading") {

		$cmdoutputcount = 0;

		while ($cmdoutputcount < count($cmdoutput)) {

			#
			# get the sensor reading for each entry
			#
			$scratch = cacti_snmp_get($snmp_hostname,
				$snmp_community,
				($oid[2][1] . "." . $cmdoutput[$cmdoutputcount][0]),
				$snmp_version,
				$snmp_username,
				$snmp_password,
				$snmp_port,
				$snmp_timeout);

			#
			# negative voltage readings must be converted to negative numbers
			#
			if (($sensor_type == "voltage") &&
				($scratch > 2147483647)) {

				$scratch = ($scratch - 4294967294);
			}

			#
			# move the voltage and thermal decimal place left by three places
			#
			if (($sensor_type == "voltage") ||
				($sensor_type == "temperature")) {

				$scratch = ($scratch / 1000);
			}

			$cmdoutput[$cmdoutputcount][2] = $scratch;

			$cmdoutputcount++;
		}
	}
}

#
# generate output
#
$outputcount = 0;

while ($outputcount < count($cmdoutput)) {

	switch ($cacti_request) {

	#
	# if they want an index, dump a list of numbers
	#
	case "index":

		echo ($cmdoutput[($outputcount)][0] . "\n");

		break;

	#
	# if they want query data, give them the type they want
	#
	case "query":

		switch ($cacti_request_type) {

		#
		# they want the index numbers
		#
		case "sensordevice":

			echo ($cmdoutput[($outputcount)][0] . ":" .
				$cmdoutput[($outputcount)][0] . "\n");

			break;

		#
		# they want the sensor name
		#
		case "sensorname":

			echo ($cmdoutput[($outputcount)][0] . ":" .
				$cmdoutput[($outputcount)][1] . "\n");

			break;

		#
		# they want the sensor reading
		#
		case "sensorreading":

			echo ($cmdoutput[($outputcount)][0] . ":" .
				$cmdoutput[($outputcount)][2] . "\n");

			break;
		}

		break;

	#
	# if they want explicit data, give them the type they want
	#
	case "get":

		switch ($cacti_request_type) {

		#
		# they want the index number
		#
		case "sensordevice":

			echo ($cmdoutput[($outputcount)][0] . "\n");

			break;

		#
		# they want the sensor name
		#
		case "sensorname":

			echo ($cmdoutput[($outputcount)][1] . "\n");

			break;

		#
		# they want the sensor reading
		#
		case "sensorreading":

			echo ($cmdoutput[($outputcount)][2] . "\n");

			break;
		}

		break;
	}

	$outputcount++;
}

exit(0);

function displaySyntax() {

	#
	# display the syntax
	#
	echo ("syntax: " . $_SERVER['argv'][0] . " (FAN|TEMPERATURE|VOLTAGE)\n" .
		"   <hostname>, [<snmp_community>], <snmp_version>,\n" .
		"   [<snmp3_username>], [<snmp3_password>], <snmp_port>, <snmp_timeout>\n" .
		"   (index|query <fieldname>|get <fieldname> <index>)\n");
}

?>
