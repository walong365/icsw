/**
 * The angular file upload module
 * @author: nerv
 * @version: 0.5.6, 2014-04-24
 */
var app = angular.module('angularFileUpload', []);
