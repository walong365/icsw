
// Not used anymore; each module-task has it's own associated clean task.

//var clean = require('gulp-clean');
//
//module.exports = function(gulp, module) {
//
//  module.task('clean', function () {
//
//    return gulp.src(module.folders.dest, { read: false })
//      .pipe(clean({ force: true }));
//
//  });
//
//
//};