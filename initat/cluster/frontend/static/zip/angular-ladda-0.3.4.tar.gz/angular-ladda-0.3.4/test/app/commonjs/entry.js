var angular = require('angular');
require('./app');

angular.bootstrap(document, ['testApp']);