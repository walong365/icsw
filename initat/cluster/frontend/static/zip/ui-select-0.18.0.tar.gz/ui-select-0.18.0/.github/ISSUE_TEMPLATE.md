The issues forum is __NOT__ for support requests. It is for bugs and feature requests only.
Please read https://github.com/angular-ui/ui-select/blob/master/CONTRIBUTING.md and search
existing issues (both open and closed) prior to opening any new issue and ensure you follow the instructions therein.

### Bug description:

### Link to minimally-working plunker that reproduces the issue:

### Version of Angular, UI-Select, and Bootstrap/Select2/Selectize CSS

Angular:

UI-Select:

Bootstrap/Select2/Selectize CSS (if applicable):
