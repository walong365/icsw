/** @module ngMap */
var ngMap = {
  services: {},
  directives: {}
};
