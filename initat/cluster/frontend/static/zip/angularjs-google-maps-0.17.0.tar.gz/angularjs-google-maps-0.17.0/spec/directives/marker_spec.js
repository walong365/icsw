/* global google, waitsFor */

describe('marker', function() {
  var elm, scope;

  /* mock Attr2Options, knowns as parser */
  var MockAttr2Options = function() { 
    var hashFilter = function(hash) {
      var newHash = {};
      for (var key in hash) {
        if (hash[key].match(regexp)) {
          newHash[key] = hash[key];
        } 
      };
      return newHash;
    };
    return {
      filter: function(attrs) {return attrs;},
      getOptions: function(attrs) {return attrs;},
      getControlOptions: function(attrs) {return hashFilter(attrs, /ControlOptions$/);},
      getEvents: function(attrs) {return hashFilter(attrs, /^on[A-E]/);}
    };
  };

  // load the marker code
  beforeEach(function() {
    module(function($provide) {
      $provide.value('Attr2Options', MockAttr2Options);
    });
    module('ngMap');
    inject(function($rootScope, $compile) {
      elm = angular.element(
        '<map center="[40.74, -74.18]">'+ 
        '  <marker position="[40.74, -74.18]" draggable="true"></marker>'+
        '  <marker position="[40.74, -74.18]" on-click="alert(1)"></marker>'+
        '</map>');
      scope = $rootScope;
      $compile(elm)(scope);
      scope.$digest();
      waitsFor(function() { 
        return scope.maps[0]; 
      });
    });
  });

  it('should set scope.markers with options ', function() {
    // scope.markers
    expect(Object.keys(scope.maps[0].markers).length).toEqual(2);
    // options from attribute
    expect(scope.maps[0].markers[0].draggable).toEqual(true);
    // contents from html
  });

  it('should set marker events', function() {
    //TODO: don't know how to get events of an infoWindow
  });
});
