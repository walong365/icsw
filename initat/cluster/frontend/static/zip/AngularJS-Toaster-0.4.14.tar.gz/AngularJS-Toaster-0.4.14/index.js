require("./toaster.js");
module.export = "angular-toaster";