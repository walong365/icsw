require('./dist/select.css');
require('./dist/select.js');
module.exports = 'ui.select';
