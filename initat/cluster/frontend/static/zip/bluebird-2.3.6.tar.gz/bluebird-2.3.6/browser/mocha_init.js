mocha.setup({
    //reporter: mocha.reporters.TAP,
    ignoreLeaks: true,
    ui: "bdd",
    timeout: 2000,
    slow: Infinity
});
