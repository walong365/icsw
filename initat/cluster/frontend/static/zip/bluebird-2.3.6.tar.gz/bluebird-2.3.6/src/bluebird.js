"use strict";
var Promise = require("./promise.js")();
module.exports = Promise;